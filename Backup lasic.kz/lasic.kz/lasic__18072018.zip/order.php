<?php
require_once "vendor/autoload.php";

$name = $_REQUEST["name"];
$phone = $_REQUEST["phone"];
$email = $_REQUEST["email"];
$from = $_REQUEST["from"];
$obl = $_REQUEST["obl"];
$message = $_REQUEST["message"];

$m =
    "Имя: $name <br>" .
    "Телефон: $phone<br>" .
    "Email: $email<br>" .
    "Область: $obl<br>" .
    "Сообщение: $message<br>" .
    "Кнопка, с которой пришла заявка: <strong>$from</strong><br>";

echo $m;

Mail::sendMail("localhost", 25, "zayavki@glazolik.kz", "7mUc_99e", "Глазолик", "glazolik.kz@yandex.ru", "Заявка", $m);