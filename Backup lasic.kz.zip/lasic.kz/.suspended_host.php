<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
  <meta charset="utf-8">
  <title>Платный хостинг сайтов Шнайдер-хост обслуживает сайт <? echo $_SERVER['SERVER_NAME']?></title>
 </head>
<body>
<link href='https://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700,800&subset=latin,cyrillic-ext,cyrillic,latin-ext' rel='stylesheet' type='text/css'>

<style>
* {font: 400 13px/1.428 'Open Sans',"Helvetica Neue",Helvetica,Arial,sans-serif;}
h1 {font-size:19px; font-weight:600;}
table {margin:3% auto 0 auto; width:70%;}
table tr td {vertical-align:top;}
table tr td:nth-child(1) {padding:0 100px 0 0;}
img {display:block; width:130px; margin:0 0 20px 0;}
a {color:#099564;}
a:hover {color:#333;}
ul li {padding:3px 0;}
ul li, p {line-height:1.5;}
table tr td div.links {border-top:1px dotted #bbb; border-bottom:1px dotted #bbb; float:left; width:100%; padding:20px 0;}

.float-none {float:none; clear:both;}
</style>


<p>&nbsp;</p>
<table>
	<tr>
    	<td>
        	<img src="http://shneider-host.ru/styles/img/logo.png">
            <a rel="nofollow" href="https://cp.shneider-host.ru/">Панель управления хостингом</a>
        </td>
        <td>
        	<h1>Ваш хост-аккаунт с сайтом <? echo $_SERVER['SERVER_NAME']?> был заблокирован</h1>
            <p>Причины могут быть следующие:</p>
            <ul>
            	<li>У вас кончился тестовый период. <a rel="nofollow" href="https://cp.shneider-host.ru/">Оплатить</a>.</li>
                <li>У вас истек срок оплаты хостинга и его необходимо оплатить. <a rel="nofollow" href="https://cp.shneider-host.ru/">Оплатить</a>.</li>
                <li>Вы были заблокированы за превышение допустимой нагрузки. Необходимо обратиться в техподдержку.</li>
                <li>Вы были заблокированы за нарушение любого из пунктов наших правил. Необходимо обратиться в техподдержку.</li>
            </ul>
            <p>Помните, что несмотря на причину блокировки, мы хотим, чтобы вы продолжали оставаться нашим клиентом. Если у вас возникли какие-либо вопросы — не стесняйтесь обратиться в нашу поддержку. Там вам обязательно помогут.</p>
            
            <div class="links">
    			<a href="https://shneider-host.ru">Хостинг сайтов</a> с бесплатным доменом при заказе от года, от 113 руб. в месяц
            </div>
            <div class="float-none"></div>
            <p>© «Шнайдер-хост» 2007–2015 <a rel="nofollow" href="https://cp.shneider-host.ru/submitticket.php?step=2&deptid=1">Написать в поддержку</a></p>
        </td>
    </tr>
</table>
</body>
</html>


